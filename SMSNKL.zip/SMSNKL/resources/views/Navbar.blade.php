<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="{{url('/')}}">Students Management</a>

    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link active" href="{{url('/')}}">Home</a>
            <a class="nav-item nav-link active" href="{{url('/create')}}">Create</a>

        </div>
    </div>
</nav>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Students Management</a>

    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link active" href="<?php echo e(url('/')); ?>">Home</a>
            <a class="nav-item nav-link active" href="<?php echo e(url('/create')); ?>">Create</a>

        </div>
    </div>
</nav>
<?php /**PATH C:\Users\asus\Desktop\SMSNKL\resources\views/Navbar.blade.php ENDPATH**/ ?>
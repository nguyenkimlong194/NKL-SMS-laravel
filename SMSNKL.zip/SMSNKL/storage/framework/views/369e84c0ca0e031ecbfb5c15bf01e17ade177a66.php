<div class="card mb-3">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAd8AAABjCAMAAADtofrQAAAAY1BMVEX///8Rko7XhTLD5ONMrar14MyIyMbrwpj89/LZjD7ho2X68OXw0bLtyaXmsn7clEvem1j36Njjq3Ly2b8fmJXw+Pjouovh8fGl1tQ9pqNqu7jS6uq03dwun5xbtLF5wb+Wz80vtbfMAAAL2ElEQVR4nO1c2YKqMAxlVHZEQMXluv3/V16hTTe6qYCiPS+j0jUnSdO0jOdNHtv5KWhwm+9GqecwHrb7y+aP4nycW9c7M/U2x9Ow43R4CgFLLsLi33P1Djb1HEbFscNSY4tmb3uV1nMEfxh2Mpr+/gJjRXm9ywhDdngAczlPR1M9hV4sxhizgz1Ocp7OQ9VzGBcHOU9/e3217ZP1pol/cwHbVypjdApuFQVfwF5F091Dnwao9zy2XXmNt+Ped2a5WQQ2oeTutlAKSmjjpBbpLwCp+/zI7rj/DteRttyBbEjnm8GMd9K9Cd8GTKCrQr+FuULM53EWBDlTG616nboJAgmuqLBV2S9Gw+8/6RNjqN8LFN5T07liZ9JBu8zIp/ZDaPi9yR+NklPZnuWdKy14a2uR80eU4WvRaLl0FYSleWj8k/OlzPRdbGfm+L2vsqrlt8E4/Kp2/IqMjqK0avg/zO+ZbCPey69qebjJylp75+/n156eN/OrCqJl67+1d9bzaz4GUGA7nwfGMZwDSQ5hfroqQg064ysv8vle19V0+FUE0YduQYWpq4ffN78ttgqBIWzUO8u91vsEkm3/Tp3HsU9RvJ1fRVa2w8Lukd2sjt9Xj2sUQWGDgy45o0w/q/f8ylyO/ZHi2/lVyUscgVSZD9ITc8P6uzi9loZVrusbfe5NcTz4pzlgUProi+0c3s+vQl5nXlhS77zZ6Yb/fHxlMHGV3zSl/VTmeFXWUKuEEdgBfgC/ijwxN2u5kc+1wx+MX0Vee2Oap2pAGkvUHKUY8EH8KhSbXZSka9deP/zB+H12Yd8+Xk8bzWnxSfzK1ZRZzqSjPBqGPza/z96/+gF+5bEliRKlJwUL0/Cf51e9IHqahj+L35O2gZH5VayvELDI2Efx1yD8arc56oY/it+DvoGx+ZWbKD5okG2CcIbrCX7PCz0CY/Lg/fweDHM47g0NjM6vPChtpy4Vp4X7GSR/9VLD8npP8Duh/CSBNFURKE6JbxbDd/yqG3hdCI9Dmqz5J+WdXPFw/BqgcvDWDfQHaRB9kAmTBkBP8Pv66yDv59f+gpwqQLtZt9AfbI8QTBtjQ/z88t2j9/Nrf0aiDMCPb3j5WHM0w4A9HH6G383txam9n9+/i62H1mywzotroMEQ/FvdWGad0zD5jQYatj6A3xEwSIhtMZ+rRXnH7+sYZgtlfD2BD48cv4NhGH41txxaCLnDt/Db8/vdP8WvYUoLITUs5xDv7l56P0UXXsidjFkg8tNc3WbH/kpw3zBcRnkBu0B12VDyYpTs2toFD+2F98s0F+UaSP5PytlC37eSFM7mpq3y/AH/axj2v4LMr103fbhKu9wJV0/PR1rM4mVDOYybw+2NH+DFMuMwFxg+mN6X3D47hZewGWF3PL8FR3QacgmCvc46/u2DS1vwGpyEcW1P0Ig9rnsr17SdB1fc60PvpkO1S3Czqre7PTyD13AM3nD64ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4OAwBqJk+e4hvAu+75eGIqW/DsPKVOpxRPe+o95blXVUzGbVKD19FKKsimcttOqNisz8fjtf56jvuFoOLfmG3tls1fMEPh1pPmOQqgsOwe96xXaea3p/HYjeO0Lmt6wasssPwDJmJaxjbwB+OdVqjHjI5TGBXjL4pWx8x4A9vh9RJUhYI+D++RXpZWXfP9KC6yJaIt8xXIfvB3FZBKG6cO/8Lrv0Fr01LkPNapCPuxy0xzdDtN57hKUu3De/UdzpPR50Ab5zGlMH8QP8PmZAffNLey/quujZNygQrcnH7+c3pQYU137qlcsCTzfNmHXQz5BVUX798I5MYmvRunmyFjc6ZdRscu9VuF/BecQtq2nVWfzL5b2xpYTzNGsHwO/E+XIlGUPafGI7xwU7/EZrpv9y2f8+f2zQ8IasutkqTbO8CTwoR/dvq/zOJvAbgloka749n7j7BISZhkkSNzrRhuk1VxziWfg1y9mnUQhbp5jfNtEHs1UYtX1USUGIgm8+03nWdJ7fSU6SFS64DmH2jap46br1IJTTqt2RT5pjuv4xPEXgNYkug57DAzYkSxhL5UPxomQr+7XYj0f55WgFrLnFuab98Pu5ZkPFGyJ882nnWfsn80KmIB9YluJQUuj4aem+HxnMjnebWH4r+A56ns4kiImGlyvhUdsqFnHIMgAg+1HJniwUGivAhDtbqszIL55nxPIb8Y14ePBxJPQ/5VwX2JsQMsPUsLGBJHJvJgNEvGU3GG4IxiJG4hNSRYTfWZEJK7ZIL1GkDr2J2X5R54XH8rvmWyG6DqoO+dq+ZP0OACPCKgqEYjbALZdyfnHA3d1Io4Z99rtgp1z0XiyZRVaQPirQqECH90a9TPwihBy/Nd+M6LVEuicJOjkexCG337DnSjwFv4g1IviiDold3r0dJ2Ih4BYdfgXOkAYGVVgTt193ayDdtOPX5/gV1FF0yHgKK2/CgNl3fBBIsQ2qwZTWDL+rpe8vCYsrpgra6hDjqFkRJ51MvmBE5OwuZL/STVxEvXN1H066XKF4yIbfJPE4fu8xMxc/E53KWQlM+rBYyS+nvRX9PONnTdxrRiTXLpIpYT5k7Fcmqq5Tb52wx4qahMsrn9o1uE10omjmt+b1hi+I2wK6m6JY8eJJHxWr+YUnGdXkRqIiU7BI5cTdNY8IIe0OyadlJOicbrSr+ZpKl9MV4ksEXTHyCzPU8svaLJ7ClDdHOn6ZNRcMs9Fk9JFZk4id45AsZgiJQ64T1T7Dp0E0AnUGtagr8EBcFY38QgCp5ZfxVKC4AyfDBwYJVrqP6AQx0y1ZVL+FYiCqhBKSYNmYk7xlzu2sCqI2vqgr8ED0BUZ+Qbn0/FJtUPQzNczIhDoABwUeMaXlGUskEsIfCkJIJ/mlHYjPUhwR8Yq6Ag/EI0wjv2LSQjE0vMhUoPiTTk56NL8gcdDglitWk438ApgrbLaHNHRj63u8y2audOAH4rJo5FfsRDE0cEeVUizTAtmedBdHIX3Hnh8x0oUImuc3Zv2B9SEcicYFftnrjviBeITZF78en2GVuLVpAZLqTBL5DsQllwfEmoymv+IOltrqXN6h5jYVJn5pz5RfJknF6QpRSCHu8bmfX+CXy45NOreBQBNNRIxlgoyZyxRh++actUd1oGLSQeTyac3Hz4oR5KRnxn5pdhJ0pURLMDhQwXPyYXJG2rHkl2oLd6Fk0qlJBDa/057Wr3NCJuMkQZPJ+tRKPcoZSTDsoJYLHJ7o+W1aTJrbACk1nYj6ScxjFOKPZNXIEe8RvmuPf239NsmZWPPLrACM15p2bgND3Hxi+TZguAdNJuKN8zCkIW9DP9H8uPZ9Hx3AF2wz0u7LWRdNLXJw2SRCM9RTG2UR+a9C328uxqN8F6m79jPiSYz80uUpSfC9fsZrae4ZTgeSG25EGCTYiEnxTr64RUu/5CZXKyIdv5F4YkxakxxGteeQaWe8bU5bpqZmfj22MRwH0HzatHMbgO6pLQkriBFRTZapAxwjdm9iSkXMQkZLoRgW9tBZ5+c2JSppyIJfxhvDrInXmnpuA9CRJI1d4EmkKQ0nAvID4ELLb5crGsnLDoBby+7eiC8Vemfml/HGZNMHs5h6boMgFayIKm4s/uC194d50OCke1bQPNPZr/KShifRpDhTVGqoYVUlrm35Zdoi+wcsjcnnNhhk3DJIb1LiH/iFiFcH/nUh/uYb2mhp46tUsEY2l8GrSxySRz7nKFaIGcpUXIbW/FLHThqfkcpfBD8Hilc5sSB6hsSjJIUL8YXOaAmyL2pyvlAkVRiq5JUy1wRqMW0BIXpc8dez1hV9QApjdahSL7zHw+gONu6cGGc4S5KcG0yK+iA3D77h3oYUzSvW3EvWTJrAXFh89FDXpbq19pFsKZQ8iJStmLsHzWIOvr8d2EiHfd/r04DNNzaXnDq+4gLhowDz/Yrchh6rb12IdIBY4BtSk3pkv6PJFPq7Yl8F8XWNnwCY73ekJnXIfkeTKTT3Db8Npb8M6yQZ+m36z0KKJ83v7v4Dqt+jm1cE8e4AAAAASUVORK5CYII=" class="card-img-top" alt="...">
    <div class="card-body">
        <h5 class="card-title">List of Students</h5>
        <p class="card-text">You can find information about Students</p>
                <table class="table">
                    <thead class="thead-light">
                    <tr>
                        <th scope="col">CNE </th>
                        <th scope="col">firstName</th>
                        <th scope="col">secondName</th>
                        <th scope="col">age</th>
                        <th scope="col">speciality</th>
                        <th scope="col">operations</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->cne); ?></td>
                            <td><?php echo e($student->firstName); ?></td>
                            <td><?php echo e($student->secondName); ?></td>
                            <td><?php echo e($student->age); ?></td>
                            <td><?php echo e($student->speciality); ?></td>
                            <td>
                                <a href="#" class="btn btn-sm btn-info">Show</a>
                                <a href="<?php echo e(url('/edit/'.$student->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <a href="#" class="btn btn-sm btn-danger">Delete</a>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
    </div>
</div>



<?php /**PATH C:\Users\asus\Desktop\SMSNKL\resources\views/studentslist.blade.php ENDPATH**/ ?>